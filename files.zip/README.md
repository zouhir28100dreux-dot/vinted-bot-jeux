# Vinted → Discord (gratuit, 0€, sans serveur)

## Comment ça marche
- GitHub exécute `vinted_monitor.py` automatiquement toutes les 10 min (gratuit et illimité sur un repo public).
- Le script interroge l'API publique de Vinted, compare avec les annonces déjà vues (`seen_items.json`), et envoie les nouvelles sur ton Discord via un **webhook** (pas besoin de créer un vrai bot Discord).

## Installation (10 min, une seule fois)

### 1. Créer le webhook Discord
1. Dans ton serveur Discord → clique sur le salon où tu veux recevoir les annonces → ⚙️ **Paramètres du salon** → **Intégrations** → **Webhooks** → **Nouveau webhook**.
2. Donne-lui un nom, clique **Copier l'URL du webhook**. Garde-la, tu en auras besoin à l'étape 3.

### 2. Créer le repo GitHub
1. Va sur https://github.com/new, crée un repo (public, gratuit — ou privé si tu préfères, ça marche aussi avec la limite de 2000 min/mois gratuites).
2. Mets tous les fichiers de ce dossier dedans (glisser-déposer sur l'interface GitHub, ou via git).

### 3. Ajouter le webhook comme "secret"
Dans ton repo GitHub → **Settings** → **Secrets and variables** → **Actions** → **New repository secret** :
- Name: `DISCORD_WEBHOOK_URL`
- Value: colle l'URL copiée à l'étape 1

### 4. (Optionnel) Personnaliser la recherche
Toujours dans **Settings → Secrets and variables → Actions**, onglet **Variables** :
- `VINTED_SEARCH` → ex: `jeux video`, `nintendo switch`, `ps5`...
- `VINTED_DOMAIN` → `vinted.fr` par défaut (change si tu vises un autre pays)

### 5. Activer le workflow
Onglet **Actions** de ton repo → si demandé, clique **"I understand my workflows, go ahead and enable them"**. Tu peux lancer un premier test manuel avec le bouton **Run workflow**.

## Si ça bloque (401/403)
Vinted a une protection anti-robot. Le script gère déjà une nouvelle tentative automatique. Si ça bloque quand même en continu :
- Espace un peu plus les recherches (change le cron à `*/15` ou `*/20` dans `.github/workflows/vinted.yml`)
- Évite de lancer le workflow manuellement trop souvent en plus du cron

## Important
- GitHub désactive automatiquement les workflows programmés (cron) après **60 jours sans activité** sur le repo — un simple commit ou un lancement manuel réactive tout.
- C'est un usage personnel pour surveiller des annonces, comme actualiser la page toi-même mais en automatique. Reste raisonnable sur la fréquence pour ne pas te faire bloquer par Vinted.
